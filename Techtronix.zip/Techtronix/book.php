<?php
if (isset($_POST['submit'])) 
{
$name=$_POST['name'];
$phone=$_POST['phone'];
$mobileBrand=$_POST['mobileBrand'];
$mobileModel=$_POST['mobileModel'];
$problem=$_POST['problem'];
$comment=$_POST['comment'];
$to="support@getonfirst.in";
$subject="$name has been sent a mail";
//html message start here
$message="<html>
<body>
<table style='width:600px;' border='1'>
<tbody>
<tr><td style='width:150px;'><strong>Name:</strong></td>
<td style='width:400px;'>$name</td>
</tr>
<tr><td style='width:150px;'><strong>Phone:</strong></td>
<td style='width:400px;'>$phone</td>
</tr>
<tr><td style='width:150px;'><strong>Brand:</strong></td>
<td style='width:400px;'>$mobileBrand</td>
</tr>
<tr><td style='width:150px;'><strong>Model:</strong></td>
<td style='width:400px;'>$mobileModel</td>
</tr>
<tr><td style='width:150px;'><strong>Issue:</strong></td>
<td style='width:400px;'>$problem</td>
</tr>
<tr><td style='width:150px;'><strong>Comment:</strong></td>
<td style='width:400px;'>$comment</td>
</tr>
</tbody>
</table>
</body>
</html>";

$headers="MIME=Version: 1.0"."\r\n";
$headers.="Content-type:text/html;charset=UTF8"."\r\n";
$headers.='From: Admin <support@getonfirst.in>'."\r\n";
$headers.='Cc:Admin <retouchitservices72@gmail.com>'."\r\n";
$headers.='Bcc:Admin<surajku.patra@gmail.com>'."\r\n";


if (mail($to, $subject, $message, $headers)) {
  echo "<script>alert('Message Sent Successfully')</script>";
}else{
  echo "<script>alert('Message Not Sent')</script>";
}
}
?>

 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Book Now</title>
    <link rel="icon" href="images/fav.png" alt="fav" title="Techtronix Services">
    
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<!--angularjs-->
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.7/angular.min.js"></script>


<style>



.head h1{
   color: blue;
   font-weight: bold;
   text-align: center;
   margin-top: 36px;
 }

 .head p{
     text-align: center;
 }

 .bookNow {
     margin:40px 0;
 }
 

 /* / Extra small devices (portrait phones, less than 576px) */
@media (max-width: 575.98px) {


 }




/* // Small devices (landscape phones, 576px and up) */
@media (min-width: 576px) and (max-width: 767.98px) {

    .svgIcons h2 {
    font-size: 39px;
}
 }




/* // Medium devices (tablets, 768px and up) */
@media (min-width: 768px) and (max-width: 991.98px) {


 }




/* // Large devices (desktops, 992px and up) */
@media (min-width: 992px) and (max-width: 1199.98px) {


 }




/* // Extra large devices (large desktops, 1200px and up) */
@media (min-width: 1200px) {


 }




 /* Navbar */

 @import url('https://fonts.googleapis.com/css?family=Kanit');

  
.nav-link {
  display: inline-block;
  color: #000;
  text-decoration: none;
}

.nav-link::after {
  content: '';
  display: block;
  width: 0;
  height: 2px;
  background: #000;
  transition: width .3s;
}

.nav-link:hover::after {
  width: 100%;
  
}


.button{
  background: rgb(97, 39, 179) ;
  color: rgb(255, 255, 255) ;
  font-size: 18px;
  border-radius: 50px;
  font-weight: 100;
  border:0px;
  }

  .nav-link{
     /* background: rgb(255, 255, 255);  */
    transition: width .3s
    
  }


  .navbar-fixed-top.scrolled{
background-color: rgba(255, 255, 255, 0.8);
transition: 500ms linear ;
  }

  


  .nav-link:hover{
    color:rgb(32, 20, 99) !important;

  }

  .nav-link:hover {
    transition: .3s ease-in-out;
}
 /* navigation underline hover effects   */



.navbar{
    position: relative;
    font-family: 'Kanit', sans-serif;
    font-weight: 700;
   /* box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.5);  */
}

.navbar .nav-link {
margin-right:30px;
}

.navbar {
    background: rgba(228, 228, 228, 0.4)
}

 /* Extra small devices (portrait phones, less than 576px)  */
@media (max-width: 575.98px) { 
  .navbar .navbar-nav .nav-item .nav-link  {
text-align: center ;
display:inline-block;
width:95%;
 /* border-bottom:1px solid rgb(190, 190, 190);  */
   }

   
.navbar .nav-button{
  margin-left: 0 !important;
  padding:20px;
}

}

  /* Small devices (landscape phones, 576px and up)  */
 @media (min-width: 576px) and (max-width: 767.98px) { 
  .navbar .navbar-nav .nav-item .nav-link  {
    text-align: center ;
    display:inline-block;
    width:97%;
    /* border-bottom:1px solid rgb(190, 190, 190);  */
       }
    
       
    .navbar .nav-button{
      margin-left: 0 !important;
      padding:20px;
    }
    

}


  /* Medium devices (tablets, 768px and up)  */
 @media (min-width: 768px) and (max-width: 991.98px) {
 
  .navbar .navbar-nav .nav-item .nav-link  {
    text-align: center ;
    display:inline-block;
    width:98%;
     /* border-bottom:1px solid rgb(190, 190, 190);  */
       }
    
       
    .navbar .nav-button{
      margin-left: 0 !important;
      padding:20px;
    }
}



  /* footer */
  .footer {
  background-color:#333333;
  /* font-family:'Roboto', sans-serif;  */
  font-family: 'Varela Round', sans-serif;
  padding: 30px;
  font-size: 15px;
  /* letter-spacing: 0.9px; */
  
}
.footer .bottom a{
 text-decoration: none;
 color:#3896fb;
 padding-bottom: 20px;
 margin-bottom: 13px;
 padding-bottom: 10px;
}
.footer .bottom1{
 padding-top: 35px;
}
.footer .bottom2{
 text-align: center;
 /* padding-top:35px; */
}
h6{
  color:white;
  font-weight: bolder;
  margin-bottom: 15px;
}
.footer p{
  color:#6f7882;
}
.footer .bottom a:hover{
  color: white;
}
.footer .bottom1 .center{
  text-align: center;
}
.footer .bottom1 {
  font-size: 50zpx;
  word-spacing: 8px;
 
}
.footer .bottom1 .c img{
  width: 33px;
  padding: 3px;
}

.bottom2 p{
  margin-top:40px;
}

/* END footer */

/* / Extra small devices (portrait phones, less than 576px) */
@media (max-width: 575.98px) { 

.footer .footerCOL {
  /* border:2px solid black; */
  display:inline-block;
  margin-top:10px;
  width:50%;
}
}
</style>

    <title>Document</title>
</head>
<body>

    
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">  <a href="index.html"> <img  class="navbar-brand" src="images/techtronixLogo.png" alt="" width="200"></a>
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                   </button>
                   <div class="collapse navbar-collapse" id="navbarNavDropdown">
                     <ul class="navbar-nav ml-auto">
                       <li class="nav-item active">
                         <a class="nav-link" href="index.html">HOME </a>
                       </li>
                       <li class="nav-item">
                         <a class="nav-link" href="about.html">ABOUT</a>
                       </li>
                      
                       <li class="nav-item dropdown">
                         <a class="nav-link " href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           SERVICES
                         </a>
                         <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                           <a class="dropdown-item" href="motorola-service-center.html">Motorola</a>
                           <a class="dropdown-item" href="lenovo-service-center.html">Lenovo</a>
                           <a class="dropdown-item" href="oneplus-service-center.html">Oneplus</a>
                           <a class="dropdown-item" href="redmi-service-center.html">Xioami</a>
                           <a class="dropdown-item" href="honor-service-center.html">Honor</a>
                         </div>
                       </li>
        
                       <li class="nav-item">
                         <a class="nav-link" href="#">BLOG</a>
                       </li>
        
                       <li class="nav-item">
                         <a class="nav-link" href="contact.html">CONTACT</a>
                       </li>
        
                       <li class="nav-item nav-button">
                       <center>  <a href="#"><button class="btn btn-primary button">Book Now</button></a> </center>
                     </li>
                     </ul>
                   </div>
                 </div>
                 </nav>
<div class=" head">
        <div class="container ">
                <h1 >Book Your Device</b></h1>
                <p>Help us to know more about your device issue/ defects by completing this quick form</p>
            </div>
        </div>

        <div class="bookNow ">
            <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <img src="images/aa.png" alt="" class="img-fluid mt-5">
                </div>

                <div class="col-sm-12 col-md-6 col-lg-6">
                        <div class="" >
                        <h2>Book Now</h2>
                        <br />
              
                        <form method="post" action="">
                          <div class="form-group"> 
                            <input
                              type="text"
                              class="form-control"
                              name="name"
                              placeholder="Enter Your Name"  onkeypress="if ( !isNaN(this.value + String.fromCharCode(event.keyCode) )) return false;" 
                            />
                          </div>
              
                         <div class="form-group">  
                            <input
                              type="text"
                              class="form-control"
                              placeholder="Enter Your Mobile Number"
                              name="phone" onkeypress="if ( isNaN(this.value + String.fromCharCode(event.keyCode) )) return false;"
                              maxlength="10" 
                            />
                          </div>

                         

                          <div class="form-group" > 






                               
                    <select id="mobile" name="mobileBrand" class="browser-default custom-select" onchange="getBrand(this.id, 'brand')">
                    <option value=""> Select Your Mobile Brand </option>
                                <option value="Motorola">Motorola</option>
                                <option value="Lenovo">Lenovo</option>
                                <option value="Xiaomi">Xiaomi</option>
                                <option value="OnePlus">OnePlus</option>
                                <option value="Honor">Honor</option>
                    </select>
                    </div>
                
                    
                    <div class="form-group" > 
                   
                    <select  id="brand" name="mobileModel" class="form-control" >
                        <option value="">Select Your Mobile Model</option>
                    </select>
                
                  </div>

                               





                <select   class="form-control" 
                  name="problem">
                  <option value=""> Select Your Problems </option>
                  <option value="Glass / Touch / LCD Issue"> Glass / Touch / LCD Issue </option>
                  <option value="Touch and LCD Repair"> Touch and LCD Repair </option>
                  <option value="Network Repair"> Network Repair </option>
                  <option value="Camera Repair"> Camera Repair </option>
                  <option value="Mic Repair"> Mic Repair </option>
                  <option value="Battery Issue"> Battery Issue </option>
                  <option value="Charging Issue"> Charging Issue </option>
                  <option value="Speaker Issue"> Speaker Issue </option>
                  <option value="Ear Speaker Issue"> Ear Speaker Issue </option>
                  <option value="Water Damage"> Water Damage </option>
                  <option value="Software Issue"> Software Issue </option>
                  <option value="Frame Housing Replacement"> Frame Housing Replacement </option>
                  <option value="Mother Board Issue"> Mother Board Issue </option>
                  <option value="Other"> Other </option>
                  </select>
                                <br>
                                <div class="form-group">
                            <textarea
                              class="form-control "
                              rows="4"
                              name="comment"
                              placeholder="Enter Your Message"
                            ></textarea>
                          </div>
                                <!-- <button type="button" name="submit" class="btn btn-primary btn-lg btn-block">SUBMIT</button> -->
                                <input type="submit" name="submit" value="submit" class="btn btn-primary btn-lg btn-block">
                                

                </div>
                
            </div>
        </div>
        </div>
        </div>

<style>
.svgIcons h2{
font-size:53px;
}

.svgIcons p{
font-size:14px;
}

.svgIcons .space {
font-size:16px;
text-align: center;
padding:20px 0;
}
</style>
        <div class="container-fluid svgIcons">
                <div class="row">
              <div class="col-md-4 col-sm-12 ">
                <h2>The Most Popular Repair Destination of<b style="color: blue;"> Marathahalli</b></h2>
              <p>     * MOST TRUSTED DEVICE SERVICE PROVIDER
              </p>
              </div>
              
              <div class="col-md-8 ">
                <div class="row">
                  <div class="col-md-3 col-sm-6">
                  <center>  <img src="svg/svg1.svg" width="70" height="70" > </center>
                  <p  class="space">Free Pickup & Drop</p>
                  </div>
              
                  <div class="col-md-3 col-sm-6">
               
                   <center> <img src="svg/svg2.svg" width="70" height="70"> </center>
                 
                    <p class="space">Onsite Repairs</p>
                    </div>
              
                    <div class="col-md-3 col-sm-6">
                      
                     <center> <img src="svg/svg3.svg" width="70" height="70" > </center>
                  
                      <p  class="space">6 Months Warranty
                        </p>
                      </div>
                      
                      <div class="col-md-3 col-sm-6">
                      <center>  <img src="svg/svg4.svg" width="70" height="70"> </center>
                        <p  class="space">Standby Phone</p>
                       </div>


                       <div class="col-md-3 col-sm-6">
                         <center>   <img src="svg/svg5.svg" width="70" height="70"> </center>
                            <p  class="space">Free Inspection</p>
                        </div>
                      
                      <div class="col-md-3 col-sm-6">
                       <center> <img src="svg/svg6.svg" width="70" height="70"> </center>
                        <p  class="space">Genuine Parts</p>
                      </div>
            
                      <div class="col-md-3 col-sm-6">
                       <center> <img src="svg/svg7.svg" width="70" height="70"> </center>
                        <p  class="space">Skilled Technicians</p>
                      </div>
            
                      <div class="col-md-3 col-sm-6">
                       <center> <img src="svg/svg8.svg" width="70" height="70"><br> </center>
                        <p  class="space" >Best Price</p>
                      </div>


                       
              
                       
                        </div>
                      </div>
                    </div>
                  </div>
              
                   
              </div>
              </div>



              <footer>
                    <div class="footer">
                    <div class="container-fluid bottom">
                        <div class="row">
                            <div class="col-md-3 col-sm-6 footerCOL">
                   
                                    <h6>TECHTRONIX</h6>
                                    <a href="index.html"> Home</a><br>
                                    <a href="about.html"> About Us </a><br>
                                    <a href="contact.html"> Contact Us </a><br>
                                    <a href="book.php"> Book Now</a><br>
                                  
                                    
                                </div>
                
                                <div class="col-md-3 col-sm-6 footerCOL">
                                    <h6>CONTACT</h6>
                                    <p><b style="color:aliceblue">Email</b><br>  
                                    <a href="contact.html"> Contact Us</a></p>  
                                    <p><b style="color:aliceblue">Telephone</b><br>  
                                    8999979990</p>  
                                   
                                    
                                </div>
                                
                                <div class="col-md-3 col-sm-6 footerCOL">
                
                                    <h6>SUPPORT</h6>
                                    <a href="book.php"> Redmi Repair</a><br>
                                    <a href="book.php">Oneplus Repair</a><br>
                                    <a href="book.php"> Lenovo Repair</a><br>
                                    <a href="book.php"> Honor Repair </a><br>
                                    <a href="book.php">Motorola Repair</a><br>
                                     
                                </div>
                
                                <div class="col-md-3 col-sm-6 footerCOL">
                                      
                                    <H6>SHOP</H6>
                                    <a href=".html">Sell Your Device </a><br>
                
                                    <a href="book.php">Dell Service </a><br>
                                    <a href="book.php">Lenovo Service</a><br>
                                    <a href="book.php">Redmi Repair </a><br>
                                </div>
                            </div>
                            </div>
                  
                        <div class="container-fluid bottom1">
                            <div class="row">
                            <div class="col-md-4 col-sm-6 Z">
                              <p><b style="color:aliceblue">Address</b><br>
                                #04, 1St Floor, Sigma Arcade Building, Main Road,
                                Marathahalli, HAL Old Airport Rd, Beside Tulasi Theatre,
                                Marathahalli, Bengaluru, Karnataka 560037 </p>
                                    
                            </div>
                
                            <div class="col-md-4 col-sm-6 c Z">
                                <h6>FOLLOW US</h6>
                               
                                <a href="#"><img src="images/social/f.png" ></a>
                        <a href="#"><img src="images/social/tweeter.png" ></a>
                        <a href="#"><img src="images/social/yt.png" ></a>
                        <a href="#"><img src="images/social/t.png"></a>
                        <a href="#"><img src="images/social/insta.png" ></a>
                        <a href="#"><img src="images/social/tum.png" ></a>
                
                                </div>
                
                                <div class="col-md-4 col-sm-12 subcribe">
                                <h6>SUBSCRIBE</h6>
                              <p>Receive products news and updates in your inbox</p>
                              <input type="email" placeholder="Email Address">
                                    </div>
                        </div>
                    </div>    
                
                        <div class="container-fluid bottom2">
                        <div class="row">
                    <div class="col-md-12"> 
                            <p>Copyrights © 2018 Techtronix.in. All Rights Reserved | Powered by <a href="#">Techtronix Services</a></p>
                             </div>
                            </div>
                </div>
                </footer>
               



              <script type="text/javascript">

function getBrand(s1, s2) {

        
    var s1 = document.getElementById(s1);
    var s2 = document.getElementById(s2);

    s2.innerHTML = "";

    if(s1.value == "Motorola"){
        var brandArray = [
                                " | Select Your Mobile Model ",
                                "Moto E4 Plus | Moto E4 Plus",
                                "Moto G6 Plus | Moto G6 Plus",
                                "Motorola One | Motorola One",
                                "Moto X4 | Moto X4",
                                "Moto G5S Plus |Moto G5S Plus",
                                "Moto C Plus | Moto C Plus",
                                "Motorola G7 | Motorola G7",
                                "Motorola G6 | Motorola G6",
                                "Motorola G6 | Motorola G6",
                                "Motorola G4 | Motorola G4"
                            ];
    }else if(s1.value == "Lenovo"){
        var brandArray = [
                                " | Select Your Mobile Model ",
                                "Lenovo K8 Plus | Lenovo K8 Plus",
                                "Lenovo Z2 Plus | Lenovo Z2 Plus",
                                "Lenovo K9 | Lenovo K9",
                                "Lenovo Phab 2 Plus | Lenovo Phab 2 Plus",
                                "Lenovo Vibe P1 | Lenovo Vibe P1",
                                "Lenovo K6 power | Lenovo K6 power",
                                "Lenovo A1 | Lenovo A1",
                                "Lenovo A6600 | Lenovo A6600",
                                "Lenovo A5 | Lenovo A5",
                                "Lenovo K8 Note | Lenovo K8 Note"
                            ];
    }else if(s1.value == "Xiaomi"){
        var brandArray = [
                                 " | Select Your Mobile Model ",
                                 "Xiaomi Redmi Note 7 Pro | Xiaomi Redmi Note 7 Pro",
                                 "Xiaomi Redmi Note 6 Pro | Xiaomi Redmi Note 6 Pro",
                                 "Xiaomi Redmi Note 5 Pro | Xiaomi Redmi Note 5 Pro",
                                 "Xiaomi Redmi Note 7 | Xiaomi Redmi Note 7",
                                 "Xiaomi Redmi Y3 | Xiaomi Redmi Y3",
                                 "Xiaomi Redmi 7 | Xiaomi Redmi 7",
                                 "Xiaomi Redmi 6A | Xiaomi Redmi 6A",
                                 "Xiaomi Redmi Go | Xiaomi Redmi Go"
                                 ];
    }else if(s1.value == "OnePlus"){
        var brandArray = [
                                " | Select Your Mobile Model ",
                                "OnePlus 7 Pro | OnePlus 7 Pro",
                                "OnePlus 6T | OnePlus 6T",
                                "OnePlus 3T | OnePlus 3T",
                                "OnePlus X | OnePlus X",
                                "OnePlus 5T | OnePlus 5T",
                                "OnePlus 6T McLaren Edition | OnePlus 6T McLaren Edition",
                                "OnePlus 3 | OnePlus 3",
                                "OnePlus 4 | OnePlus 4",
                                "OnePlus 5 | OnePlus 5"
                            ];
    }else if(s1.value == "Honor"){
        var brandArray = [
                                " | Select Your Mobile Model ",
                                "Honor 10i | Honor 10i",
                                "Honor Play 8A | Honor Play 8A",
                                "Honor View 20 | Honor View 20",
                                "Honor 10 Lite | Honor 10 Lite",
                                "Honor Magic 2 3D | Honor Magic 2 3D",
                                "Honor 8C | Honor 8C",
                                "Honor Note 10 | Honor Note 10",
                                "Honor 8X Max | Honor 8X Max",
                                "Honor 6C Pro | Honor 6C Pro",
                                "Honor Holly 4 | Honor Holly 4"
                            ];
    }

    for(var option in brandArray){

        var pair = brandArray[option].split("|");
        var newBrand = document.createElement("option");
        newBrand.value = pair[0];
        newBrand.innerHTML = pair[1];
        s2.options.add(newBrand);
    }
}
</script>

              
    
</body>
</html>